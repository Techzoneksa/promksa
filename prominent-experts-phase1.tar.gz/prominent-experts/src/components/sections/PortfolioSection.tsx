"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";
import { PROJECTS } from "@/lib/constants";

const TABS = ["الكل", "مواقع", "متاجر", "تطبيقات", "هوية"] as const;
type Tab = (typeof TABS)[number];

export default function PortfolioSection() {
  const [active, setActive] = useState<Tab>("الكل");

  const filtered =
    active === "الكل"
      ? PROJECTS
      : PROJECTS.filter((p) => p.category === active);

  return (
    <section id="portfolio" className="section-padding" style={{ background: "#f7f8fc" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          badge="أعمالنا"
          title="شاهد آخر مشاريعنا"
          subtitle="قمنا بتصميم وتطوير مشاريع متنوعة تعكس مستوانا الاحترافي"
        />

        {/* Filter tabs */}
        <Reveal>
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {TABS.map((tab) => (
              <button
                key={tab}
                onClick={() => setActive(tab)}
                className="text-sm font-bold px-5 py-2 rounded-full transition-all duration-200"
                style={
                  active === tab
                    ? {
                        background: "linear-gradient(135deg, #7448f5, #5a32c8)",
                        color: "#fff",
                        boxShadow: "0 4px 14px rgba(116,72,245,0.3)",
                      }
                    : {
                        background: "#fff",
                        color: "#6b6b7a",
                        border: "1px solid #e5e5e5",
                      }
                }
              >
                {tab}
              </button>
            ))}
          </div>
        </Reveal>

        {/* Projects grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <AnimatePresence mode="popLayout">
            {filtered.map((project, i) => (
              <motion.div
                key={project.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ delay: i * 0.07, duration: 0.3 }}
              >
                <motion.div
                  className="relative rounded-2xl overflow-hidden group cursor-pointer"
                  style={{
                    background: project.color,
                    height: 220,
                  }}
                  whileHover={{ y: -4 }}
                >
                  {/* Mock website inside */}
                  <div className="absolute inset-3 rounded-xl overflow-hidden opacity-30"
                    style={{ background: "rgba(255,255,255,0.1)" }}>
                    <div className="p-3 space-y-2">
                      <div className="h-2.5 rounded w-1/2 bg-white/40" />
                      <div className="h-2 rounded w-full bg-white/25" />
                      <div className="h-2 rounded w-3/4 bg-white/20" />
                      <div className="grid grid-cols-3 gap-1.5 mt-2">
                        {[...Array(6)].map((_, j) => (
                          <div key={j} className="h-10 rounded bg-white/20" />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Tag */}
                  <div className="absolute top-3 right-3">
                    <span
                      className="text-xs font-bold px-2.5 py-1 rounded-full"
                      style={{ background: "rgba(255,255,255,0.2)", color: "#fff" }}
                    >
                      {project.tag}
                    </span>
                  </div>

                  {/* Hover overlay */}
                  <motion.div
                    className="absolute inset-0 flex flex-col justify-end p-5"
                    style={{
                      background: "linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 50%)",
                    }}
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                  >
                    <h3 className="text-white font-extrabold text-base">{project.title}</h3>
                    <a
                      href="#"
                      className="text-sm font-bold mt-1 flex items-center gap-1"
                      style={{ color: "#41c7d7" }}
                    >
                      عرض المشروع ↗
                    </a>
                  </motion.div>

                  {/* Always visible title at bottom */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 group-hover:opacity-0 transition-opacity">
                    <h3 className="text-white font-extrabold text-sm">{project.title}</h3>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        <Reveal delay={0.2}>
          <div className="text-center mt-10">
            <a
              href="#"
              className="inline-flex items-center gap-2 text-sm font-bold px-6 py-3 rounded-[10px] transition-all hover:scale-105"
              style={{
                border: "2px solid #7448f5",
                color: "#7448f5",
              }}
            >
              عرض كل الأعمال ←
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
