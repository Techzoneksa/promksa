"use client";
import { useState } from "react";
import { Send, CheckCircle } from "lucide-react";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";

const SERVICES_LIST = [
  "تصميم موقع إلكتروني",
  "تصميم متجر إلكتروني",
  "برمجة تطبيق جوال",
  "تصميم هوية بصرية",
  "التسويق الرقمي",
  "الربط والتكامل التقني",
  "استشارة مجانية",
];

interface FormData {
  name: string;
  email: string;
  phone: string;
  service: string;
  message: string;
}

export default function ContactSection() {
  const [form, setForm] = useState<FormData>({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1200);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const inputStyle = {
    width: "100%",
    padding: "12px 14px",
    borderRadius: 10,
    border: "1.5px solid #e5e5e5",
    fontSize: 14,
    fontFamily: "Almarai, sans-serif",
    color: "#1f1f2e",
    outline: "none",
    transition: "border-color 0.2s",
    background: "#fff",
  };

  return (
    <section id="contact" className="section-padding" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          badge="تواصل معنا"
          title="خلّنا نناقش مشروعك"
          subtitle="أرسل لنا تفاصيل مشروعك وسنتواصل معك في أقرب وقت"
        />

        <div className="max-w-2xl mx-auto">
          {submitted ? (
            <Reveal>
              <div
                className="rounded-2xl p-10 text-center"
                style={{ background: "#f4f0ff", border: "1px solid rgba(116,72,245,0.15)" }}
              >
                <CheckCircle size={48} className="mx-auto mb-4" style={{ color: "#7448f5" }} />
                <h3 className="text-xl font-extrabold mb-2" style={{ color: "#1f1f2e" }}>
                  تم إرسال طلبك بنجاح!
                </h3>
                <p className="text-sm" style={{ color: "#6b6b7a" }}>
                  شكراً لتواصلك معنا. سيتواصل معك فريقنا خلال 24 ساعة.
                </p>
                <button
                  onClick={() => { setSubmitted(false); setForm({ name: "", email: "", phone: "", service: "", message: "" }); }}
                  className="mt-5 text-sm font-bold px-5 py-2.5 rounded-[10px] transition-all hover:scale-105"
                  style={{ background: "#7448f5", color: "#fff" }}
                >
                  إرسال طلب جديد
                </button>
              </div>
            </Reveal>
          ) : (
            <Reveal>
              <form
                onSubmit={handleSubmit}
                className="rounded-2xl p-8 space-y-4"
                style={{
                  background: "#fff",
                  boxShadow: "0 4px 40px rgba(116,72,245,0.10)",
                  border: "1px solid rgba(116,72,245,0.08)",
                }}
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold mb-1.5" style={{ color: "#1f1f2e" }}>
                      الاسم *
                    </label>
                    <input
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      required
                      placeholder="اسمك الكريم"
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = "#7448f5")}
                      onBlur={(e) => (e.target.style.borderColor = "#e5e5e5")}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-1.5" style={{ color: "#1f1f2e" }}>
                      رقم الجوال *
                    </label>
                    <input
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      required
                      placeholder="05XXXXXXXX"
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = "#7448f5")}
                      onBlur={(e) => (e.target.style.borderColor = "#e5e5e5")}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-1.5" style={{ color: "#1f1f2e" }}>
                    البريد الإلكتروني
                  </label>
                  <input
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="example@email.com"
                    style={inputStyle}
                    onFocus={(e) => (e.target.style.borderColor = "#7448f5")}
                    onBlur={(e) => (e.target.style.borderColor = "#e5e5e5")}
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold mb-1.5" style={{ color: "#1f1f2e" }}>
                    الخدمة المطلوبة *
                  </label>
                  <select
                    name="service"
                    value={form.service}
                    onChange={handleChange}
                    required
                    style={{ ...inputStyle, cursor: "pointer" }}
                    onFocus={(e) => (e.target.style.borderColor = "#7448f5")}
                    onBlur={(e) => (e.target.style.borderColor = "#e5e5e5")}
                  >
                    <option value="">اختر الخدمة</option>
                    {SERVICES_LIST.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-1.5" style={{ color: "#1f1f2e" }}>
                    الرسالة
                  </label>
                  <textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    rows={4}
                    placeholder="أخبرنا عن مشروعك..."
                    style={{ ...inputStyle, resize: "vertical" }}
                    onFocus={(e) => (e.target.style.borderColor = "#7448f5")}
                    onBlur={(e) => (e.target.style.borderColor = "#e5e5e5")}
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center gap-2 py-3.5 rounded-[10px] font-extrabold text-sm transition-all hover:scale-[1.02] disabled:opacity-70"
                  style={{
                    background: "linear-gradient(135deg, #7448f5, #5a32c8)",
                    color: "#fff",
                    boxShadow: "0 4px 20px rgba(116,72,245,0.3)",
                  }}
                >
                  {loading ? (
                    <span>جاري الإرسال...</span>
                  ) : (
                    <>
                      <Send size={16} />
                      إرسال الطلب
                    </>
                  )}
                </button>
              </form>
            </Reveal>
          )}
        </div>
      </div>
    </section>
  );
}
