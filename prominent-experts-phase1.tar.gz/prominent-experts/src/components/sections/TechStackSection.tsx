"use client";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";
import { motion } from "framer-motion";
import { TECH_STACK } from "@/lib/constants";

export default function TechStackSection() {
  return (
    <section className="section-padding" style={{ background: "#f7f8fc" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          badge="التقنيات"
          title="التقنيات المستخدمة"
          subtitle="نستخدم أحدث التقنيات لضمان أفضل أداء وجودة لمشروعك"
        />

        <Reveal>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-4">
            {TECH_STACK.map((tech, i) => (
              <motion.div
                key={tech.name}
                className="rounded-xl p-4 flex flex-col items-center gap-2 cursor-default"
                style={{
                  background: "#fff",
                  border: "1px solid #eee",
                  boxShadow: "0 2px 10px rgba(116,72,245,0.05)",
                }}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05, duration: 0.3 }}
                whileHover={{
                  y: -3,
                  borderColor: "#c4aaff",
                  boxShadow: "0 6px 20px rgba(116,72,245,0.12)",
                }}
              >
                <span className="text-2xl">{tech.icon}</span>
                <span className="text-xs font-bold text-center" style={{ color: "#1f1f2e" }}>
                  {tech.name}
                </span>
              </motion.div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
