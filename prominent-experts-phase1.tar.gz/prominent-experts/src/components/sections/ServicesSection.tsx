"use client";
import { motion } from "framer-motion";
import {
  Monitor, ShoppingCart, Smartphone, Palette, TrendingUp, Link,
} from "lucide-react";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";
import { SERVICES } from "@/lib/constants";

const ICON_MAP = { Monitor, ShoppingCart, Smartphone, Palette, TrendingUp, Link };

type IconKey = keyof typeof ICON_MAP;

export default function ServicesSection() {
  return (
    <section id="services" className="section-padding" style={{ background: "#f7f8fc" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          badge="خدماتنا"
          title="خدماتنا الرقمية التي تدعم نجاحك"
          subtitle="في بروميننت اكسبيرتس نضع الإبداع والابتكار في قلب كل خدمة نقدمها لنصنع لك تجربة متكاملة تعكس هوية مشروعك."
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((service, i) => {
            const Icon = ICON_MAP[service.icon as IconKey];
            return (
              <Reveal key={service.id} delay={i * 0.08}>
                <motion.div
                  className="rounded-2xl p-6 h-full flex flex-col cursor-pointer"
                  style={{
                    background: "linear-gradient(135deg, #7448f5 0%, #5a32c8 100%)",
                    color: "#fff",
                  }}
                  whileHover={{
                    y: -5,
                    boxShadow: "0 16px 48px rgba(116,72,245,0.4)",
                  }}
                  transition={{ duration: 0.25 }}
                >
                  {/* Number */}
                  <span
                    className="text-xs font-extrabold mb-4 self-start px-2 py-0.5 rounded"
                    style={{ background: "rgba(255,255,255,0.15)", color: "rgba(255,255,255,0.7)" }}
                  >
                    0{service.id}
                  </span>

                  {/* Icon */}
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                    style={{ background: "rgba(255,255,255,0.15)" }}
                  >
                    <Icon size={24} color="#fff" />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-extrabold mb-2 text-white">
                    {service.title}
                  </h3>
                  <p className="text-sm leading-relaxed flex-1" style={{ color: "rgba(255,255,255,0.8)" }}>
                    {service.description}
                  </p>

                  {/* Link */}
                  <a
                    href={service.link}
                    className="mt-4 text-sm font-bold flex items-center gap-1 self-start transition-all hover:gap-2"
                    style={{ color: "#41c7d7" }}
                  >
                    تعرف على المزايا ←
                  </a>
                </motion.div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
