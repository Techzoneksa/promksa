"use client";
import { motion } from "framer-motion";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";

const CLIENT_NAMES = [
  "شركة التوباز", "شركة أبعاد", "مهل للمياه", "الزهراني للبلاستيك",
  "هوم مارت", "أحافير المحدودة", "سهم العقارية", "المعتمد لحلول الأعمال",
  "مواسم للسفر", "Next Care", "كيدز زون", "اكسترا باسيكال",
  "شركة البناء الأول", "بوفارديا لاونج", "شركة جسور", "مصنع الواحة",
  "نظم التخزين", "فندق دريم ويفز", "غذاء الطبيعة", "شركة حديث التقنية",
  "مجموعة النور", "الأفق للمقاولات", "دار التميز", "واحة الإبداع",
];

export default function ClientsSection() {
  return (
    <section className="section-padding" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          badge="عملاؤنا"
          title="عملاؤنا وشركاء النجاح"
          subtitle="نفخر بنجاحات صنعناها مع شركائنا في كل إنجاز"
        />

        <Reveal>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {CLIENT_NAMES.map((name, i) => (
              <motion.div
                key={name}
                className="rounded-xl flex items-center justify-center p-3 text-center"
                style={{
                  background: "#f7f8fc",
                  border: "1px solid #eee",
                  minHeight: 72,
                }}
                whileHover={{
                  scale: 1.05,
                  background: "#f4f0ff",
                  borderColor: "#c4aaff",
                }}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03, duration: 0.3 }}
              >
                <span
                  className="text-xs font-bold leading-tight"
                  style={{ color: "#6b6b7a" }}
                >
                  {name}
                </span>
              </motion.div>
            ))}
          </div>
        </Reveal>

        {/* Trust badge */}
        <Reveal delay={0.3}>
          <div className="mt-10 flex flex-wrap justify-center items-center gap-6 text-center">
            {[
              { value: "+129", label: "عميل راضٍ" },
              { value: "4.7★", label: "متوسط التقييم" },
              { value: "+8", label: "سنوات في السوق" },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center">
                <span
                  className="text-2xl font-extrabold"
                  style={{ color: "#7448f5" }}
                >
                  {item.value}
                </span>
                <span className="text-xs font-medium mt-1" style={{ color: "#6b6b7a" }}>
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
