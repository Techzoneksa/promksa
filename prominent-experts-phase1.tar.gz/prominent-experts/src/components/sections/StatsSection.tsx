"use client";
import Reveal from "@/components/ui/Reveal";
import StatCounter from "@/components/ui/StatCounter";
import { STATS } from "@/lib/constants";

type StatIconKey = "Star" | "Users" | "Briefcase" | "Award";

export default function StatsSection() {
  return (
    <section style={{ background: "#f7f8fc" }} className="py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {STATS.map((stat, i) => (
            <Reveal key={stat.label} delay={i * 0.1}>
              <StatCounter
                value={stat.value}
                suffix={stat.suffix}
                label={stat.label}
                icon={stat.icon as StatIconKey}
                delay={i * 0.15}
              />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
