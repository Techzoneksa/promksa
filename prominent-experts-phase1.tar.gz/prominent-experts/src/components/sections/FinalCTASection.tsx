"use client";
import Reveal from "@/components/ui/Reveal";
import CTAButton from "@/components/ui/CTAButton";
import { WHATSAPP_URL } from "@/lib/constants";

export default function FinalCTASection() {
  return (
    <section
      className="relative overflow-hidden py-20"
      style={{ background: "#f4f0ff" }}
    >
      {/* Decorative circles */}
      <div
        className="absolute top-[-60px] left-[-60px] w-80 h-80 rounded-full opacity-30 pointer-events-none"
        style={{ background: "radial-gradient(circle, #7448f5, transparent)" }}
      />
      <div
        className="absolute bottom-[-60px] right-[-60px] w-64 h-64 rounded-full opacity-20 pointer-events-none"
        style={{ background: "radial-gradient(circle, #41c7d7, transparent)" }}
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center relative z-10">
        <Reveal>
          <span
            className="inline-block text-sm font-bold mb-4 px-4 py-1 rounded-full"
            style={{ background: "rgba(116,72,245,0.1)", color: "#7448f5" }}
          >
            ابدأ معنا الآن
          </span>
        </Reveal>

        <Reveal delay={0.05}>
          <h2
            className="text-3xl md:text-5xl font-extrabold leading-tight mb-5"
            style={{ color: "#1f1f2e" }}
          >
            طموحك الرقمي{" "}
            <span style={{ color: "#7448f5" }}>يبدأ من هنا</span>
          </h2>
        </Reveal>

        <Reveal delay={0.1}>
          <p
            className="text-base md:text-lg leading-relaxed mb-8 max-w-xl mx-auto"
            style={{ color: "#6b6b7a" }}
          >
            مع بروميننت اكسبيرتس، مشروعك يستحق المنافسة. نحن هنا لنحوّل أفكارك إلى واقع رقمي يُذهل منافسيك.
          </p>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <CTAButton href={WHATSAPP_URL} variant="primary" external>
              تواصل معنا
            </CTAButton>
            <CTAButton href={WHATSAPP_URL} variant="cyan" external>
              واتساب مباشر
            </CTAButton>
          </div>
        </Reveal>

        <Reveal delay={0.2}>
          <div className="mt-8 flex flex-wrap justify-center gap-6">
            {["✓ بدون تكاليف استشارة", "✓ رد خلال 24 ساعة", "✓ عرض سعر مجاني"].map((item) => (
              <span key={item} className="text-sm font-medium" style={{ color: "#6b6b7a" }}>
                {item}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
