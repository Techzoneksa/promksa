"use client";
import Reveal from "@/components/ui/Reveal";
import CTAButton from "@/components/ui/CTAButton";
import { WHATSAPP_URL } from "@/lib/constants";

export default function AboutTeaser() {
  return (
    <section className="section-padding" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text */}
          <div>
            <Reveal>
              <span
                className="inline-block text-sm font-bold mb-3 px-4 py-1 rounded-full"
                style={{ background: "#f4f0ff", color: "#7448f5" }}
              >
                من نحن
              </span>
            </Reveal>
            <Reveal delay={0.05}>
              <h2
                className="text-3xl md:text-4xl font-extrabold leading-tight mb-5"
                style={{ color: "#1f1f2e" }}
              >
                بصمات إبداعية تجعل{" "}
                <span style={{ color: "#7448f5" }}>مشروعك مميزاً</span>{" "}
                عن الآخرين
              </h2>
            </Reveal>
            <Reveal delay={0.1}>
              <p
                className="text-base leading-relaxed mb-6"
                style={{ color: "#6b6b7a" }}
              >
                بروميننت اكسبيرتس وكالة رقمية متكاملة تقدّم حلولاً إبداعية وتقنية لتحويل أفكارك إلى مشاريع ناجحة. بدءاً من التصميم والتطوير وصولاً إلى التسويق والانطلاق بقوة في السوق.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <ul className="space-y-3 mb-8">
                {[
                  "فريق متخصص يجمع التصميم والتقنية والتسويق",
                  "حلول مخصصة لكل مشروع وليست قوالب جاهزة",
                  "دعم ومتابعة مستمرة بعد الإطلاق",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <span
                      className="w-5 h-5 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                      style={{ background: "#7448f5" }}
                    >
                      ✓
                    </span>
                    <span className="text-sm font-medium" style={{ color: "#1f1f2e" }}>
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            </Reveal>
            <Reveal delay={0.2}>
              <CTAButton href={WHATSAPP_URL} variant="primary" external>
                تواصل معنا
              </CTAButton>
            </Reveal>
          </div>

          {/* Visual side */}
          <Reveal delay={0.15} direction="left">
            <div className="relative">
              <div
                className="rounded-2xl overflow-hidden"
                style={{
                  background: "linear-gradient(135deg, #f4f0ff 0%, #e8e0ff 100%)",
                  height: 380,
                  border: "1px solid rgba(116,72,245,0.1)",
                }}
              >
                {/* Decorative content */}
                <div className="p-8 h-full flex flex-col justify-between">
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: "تصميم", count: "100+", color: "#7448f5" },
                      { label: "تطوير", count: "150+", color: "#5a32c8" },
                      { label: "تسويق", count: "80+", color: "#41c7d7" },
                      { label: "هوية", count: "60+", color: "#7448f5" },
                    ].map((item) => (
                      <div
                        key={item.label}
                        className="rounded-xl p-4 text-center"
                        style={{ background: "rgba(255,255,255,0.7)" }}
                      >
                        <div
                          className="text-2xl font-extrabold"
                          style={{ color: item.color }}
                        >
                          {item.count}
                        </div>
                        <div className="text-xs font-bold mt-1" style={{ color: "#6b6b7a" }}>
                          {item.label}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div
                    className="rounded-xl p-4 flex items-center gap-4"
                    style={{ background: "rgba(255,255,255,0.9)" }}
                  >
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-extrabold text-xl shrink-0"
                      style={{ background: "linear-gradient(135deg,#7448f5,#5a32c8)" }}
                    >
                      P
                    </div>
                    <div>
                      <div className="font-extrabold text-sm" style={{ color: "#1f1f2e" }}>
                        بروميننت اكسبيرتس
                      </div>
                      <div className="text-xs mt-0.5" style={{ color: "#6b6b7a" }}>
                        وكالة رقمية متكاملة — جدة، السعودية
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Accent dot */}
              <div
                className="absolute -top-3 -right-3 w-6 h-6 rounded-full"
                style={{ background: "#41c7d7" }}
              />
              <div
                className="absolute -bottom-3 -left-3 w-10 h-10 rounded-full opacity-40"
                style={{ background: "#7448f5" }}
              />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
