"use client";
import { motion } from "framer-motion";
import { TECH_PLATFORMS } from "@/lib/constants";

export default function TechPlatformsStrip() {
  const platforms = [...TECH_PLATFORMS, ...TECH_PLATFORMS];

  return (
    <div
      className="py-4 overflow-hidden"
      style={{ background: "linear-gradient(90deg, #7448f5 0%, #5a32c8 100%)" }}
    >
      <motion.div
        className="flex items-center gap-10 whitespace-nowrap"
        animate={{ x: ["0%", "-50%"] }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      >
        {platforms.map((name, i) => (
          <span
            key={`${name}-${i}`}
            className="text-sm font-extrabold flex items-center gap-3 shrink-0"
            style={{ color: "rgba(255,255,255,0.9)" }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: "#41c7d7" }}
            />
            {name}
          </span>
        ))}
      </motion.div>
    </div>
  );
}
