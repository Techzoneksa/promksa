"use client";
import { CheckCircle } from "lucide-react";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";
import CTAButton from "@/components/ui/CTAButton";
import { WHY_US, WHATSAPP_URL } from "@/lib/constants";

export default function WhyUsSection() {
  return (
    <section className="section-padding" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: visual */}
          <Reveal direction="right">
            <div
              className="rounded-2xl p-8 relative overflow-hidden"
              style={{
                background: "linear-gradient(135deg, #2b145f 0%, #7448f5 100%)",
                minHeight: 340,
              }}
            >
              {/* Decorative */}
              <div
                className="absolute top-0 right-0 w-48 h-48 rounded-full opacity-20"
                style={{ background: "radial-gradient(circle, #41c7d7, transparent)", transform: "translate(30%, -30%)" }}
              />

              <div className="relative z-10 text-white h-full flex flex-col justify-between gap-6">
                <div>
                  <div className="text-5xl font-extrabold mb-2">+8</div>
                  <div className="text-base opacity-80">سنوات في السوق السعودي</div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {[
                    { v: "+376", l: "مشروع ناجح" },
                    { v: "+129", l: "عميل راضٍ" },
                    { v: "4.7★", l: "تقييم" },
                    { v: "100%", l: "التزام بالجودة" },
                  ].map((item) => (
                    <div
                      key={item.l}
                      className="rounded-xl p-3 text-center"
                      style={{ background: "rgba(255,255,255,0.12)" }}
                    >
                      <div className="text-xl font-extrabold">{item.v}</div>
                      <div className="text-xs opacity-75 mt-0.5">{item.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>

          {/* Right: text */}
          <div>
            <SectionTitle
              badge="لماذا نحن؟"
              title="لماذا بروميننت اكسبيرتس؟"
              subtitle="لأننا لا نقدم خدمة فقط، بل نبني تجربة رقمية متكاملة تساعد مشروعك على النمو."
              center={false}
            />

            <div className="space-y-4 mb-8">
              {WHY_US.map((point, i) => (
                <Reveal key={point} delay={i * 0.08}>
                  <div className="flex items-center gap-3">
                    <CheckCircle
                      size={20}
                      className="shrink-0"
                      style={{ color: "#7448f5" }}
                    />
                    <span className="text-sm font-medium" style={{ color: "#1f1f2e" }}>
                      {point}
                    </span>
                  </div>
                </Reveal>
              ))}
            </div>

            <Reveal delay={0.3}>
              <CTAButton href={WHATSAPP_URL} variant="primary" external>
                ابدأ مشروعك معنا
              </CTAButton>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
