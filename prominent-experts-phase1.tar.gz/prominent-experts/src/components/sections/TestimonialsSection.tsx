"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronRight, ChevronLeft, Star } from "lucide-react";
import SectionTitle from "@/components/ui/SectionTitle";
import Reveal from "@/components/ui/Reveal";
import { TESTIMONIALS } from "@/lib/constants";

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent((c) => (c - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  const next = () => setCurrent((c) => (c + 1) % TESTIMONIALS.length);

  return (
    <section className="section-padding" style={{ background: "#f7f8fc" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionTitle
          badge="آراء العملاء"
          title="تقييمات عملائنا"
          subtitle="رضاك عن مشروعك هو صوت النجاح الحقيقي"
        />

        {/* Desktop: 3 cards */}
        <div className="hidden md:grid grid-cols-3 gap-5">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.id} delay={i * 0.1}>
              <div
                className="rounded-2xl p-6 h-full flex flex-col"
                style={{
                  background: "#fff",
                  boxShadow: "0 4px 24px rgba(116,72,245,0.08)",
                  border: "1px solid rgba(116,72,245,0.06)",
                }}
              >
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(t.rating)].map((_, j) => (
                    <Star key={j} size={14} fill="#7448f5" color="#7448f5" />
                  ))}
                </div>

                {/* Quote */}
                <p
                  className="text-sm leading-relaxed flex-1 mb-5"
                  style={{ color: "#6b6b7a" }}
                >
                  &ldquo;{t.text}&rdquo;
                </p>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4" style={{ borderTop: "1px solid #f4f0ff" }}>
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-extrabold shrink-0"
                    style={{ background: "linear-gradient(135deg,#7448f5,#5a32c8)" }}
                  >
                    {t.name[0]}
                  </div>
                  <div>
                    <div className="font-extrabold text-sm" style={{ color: "#1f1f2e" }}>
                      {t.name}
                    </div>
                    <div className="text-xs" style={{ color: "#6b6b7a" }}>
                      {t.company}
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Mobile: single carousel */}
        <div className="md:hidden">
          <div className="relative overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
                className="rounded-2xl p-6"
                style={{ background: "#fff", boxShadow: "0 4px 24px rgba(116,72,245,0.08)" }}
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(TESTIMONIALS[current].rating)].map((_, j) => (
                    <Star key={j} size={14} fill="#7448f5" color="#7448f5" />
                  ))}
                </div>
                <p className="text-sm leading-relaxed mb-5" style={{ color: "#6b6b7a" }}>
                  &ldquo;{TESTIMONIALS[current].text}&rdquo;
                </p>
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-extrabold"
                    style={{ background: "linear-gradient(135deg,#7448f5,#5a32c8)" }}
                  >
                    {TESTIMONIALS[current].name[0]}
                  </div>
                  <div>
                    <div className="font-extrabold text-sm" style={{ color: "#1f1f2e" }}>
                      {TESTIMONIALS[current].name}
                    </div>
                    <div className="text-xs" style={{ color: "#6b6b7a" }}>
                      {TESTIMONIALS[current].company}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="flex justify-center items-center gap-4 mt-5">
            <button
              onClick={prev}
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ background: "#fff", border: "1px solid #e5e5e5", color: "#7448f5" }}
            >
              <ChevronRight size={18} />
            </button>
            <div className="flex gap-2">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className="rounded-full transition-all"
                  style={{
                    width: i === current ? 20 : 8,
                    height: 8,
                    background: i === current ? "#7448f5" : "#d1d1d1",
                  }}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ background: "#fff", border: "1px solid #e5e5e5", color: "#7448f5" }}
            >
              <ChevronLeft size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
