"use client";
import { motion } from "framer-motion";
import CTAButton from "@/components/ui/CTAButton";
import { WHATSAPP_URL } from "@/lib/constants";

export default function HeroSection() {
  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #2b145f 0%, #4a2a9e 50%, #7448f5 100%)",
      }}
    >
      {/* Decorative circles */}
      <div
        className="absolute top-[-80px] left-[-80px] w-[400px] h-[400px] rounded-full opacity-20 pointer-events-none"
        style={{ background: "radial-gradient(circle, #41c7d7, transparent)" }}
      />
      <div
        className="absolute bottom-[-100px] right-[-60px] w-[350px] h-[350px] rounded-full opacity-15 pointer-events-none"
        style={{ background: "radial-gradient(circle, #7448f5, transparent)" }}
      />

      {/* Dot pattern overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-10"
        style={{
          backgroundImage: "radial-gradient(circle, rgba(255,255,255,0.6) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-0 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Text side (right in RTL) */}
          <div className="text-white">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span
                className="inline-flex items-center gap-2 text-sm font-bold px-4 py-1.5 rounded-full mb-6"
                style={{ background: "rgba(65,199,215,0.2)", color: "#41c7d7", border: "1px solid rgba(65,199,215,0.3)" }}
              >
                ✦ وكالة رقمية سعودية رائدة
              </span>
            </motion.div>

            <motion.h1
              className="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight mb-6"
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.1 }}
            >
              منصة تجمع{" "}
              <span style={{ color: "#41c7d7" }}>كل احتياجاتك</span>{" "}
              الرقمية
            </motion.h1>

            <motion.p
              className="text-base md:text-lg leading-relaxed mb-8 max-w-lg"
              style={{ color: "rgba(255,255,255,0.8)" }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              وكالة تصميم وتسويق رقمي في السعودية، نساعدك في بناء مواقع ومتاجر وتطبيقات وهوية رقمية تليق بطموح مشروعك.
            </motion.p>

            <motion.div
              className="flex flex-wrap gap-3"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              <CTAButton href={WHATSAPP_URL} variant="cyan" external>
                تواصل معنا
              </CTAButton>
              <CTAButton href="#portfolio" variant="white-outline">
                شاهد أعمالنا
              </CTAButton>
            </motion.div>

            {/* Mini trust badges */}
            <motion.div
              className="flex flex-wrap items-center gap-4 mt-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              {["✓ خبرة +15 سنة", "✓ +376 مشروع", "✓ تقييم 4.7★"].map((item) => (
                <span
                  key={item}
                  className="text-xs font-bold"
                  style={{ color: "rgba(255,255,255,0.7)" }}
                >
                  {item}
                </span>
              ))}
            </motion.div>
          </div>

          {/* Image/visual side */}
          <motion.div
            className="relative hidden lg:flex justify-center items-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            {/* Mockup placeholder */}
            <div className="relative">
              {/* Glow behind */}
              <div
                className="absolute inset-0 rounded-3xl blur-3xl opacity-40"
                style={{ background: "rgba(65,199,215,0.4)", transform: "scale(1.1)" }}
              />
              {/* Browser mockup */}
              <div
                className="relative rounded-2xl overflow-hidden"
                style={{
                  background: "rgba(255,255,255,0.08)",
                  backdropFilter: "blur(10px)",
                  border: "1px solid rgba(255,255,255,0.15)",
                  width: 440,
                }}
              >
                {/* Browser bar */}
                <div
                  className="flex items-center gap-2 px-4 py-3"
                  style={{ background: "rgba(255,255,255,0.05)", borderBottom: "1px solid rgba(255,255,255,0.1)" }}
                >
                  <div className="w-3 h-3 rounded-full" style={{ background: "#ff5f57" }} />
                  <div className="w-3 h-3 rounded-full" style={{ background: "#ffbd2e" }} />
                  <div className="w-3 h-3 rounded-full" style={{ background: "#28c840" }} />
                  <div
                    className="flex-1 mx-3 rounded-md h-6 flex items-center px-3 text-xs"
                    style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }}
                  >
                    promksa.com
                  </div>
                </div>
                {/* Website preview */}
                <div className="p-6 space-y-3">
                  <div className="h-4 rounded-lg w-2/3" style={{ background: "rgba(116,72,245,0.6)" }} />
                  <div className="h-3 rounded-lg w-full" style={{ background: "rgba(255,255,255,0.15)" }} />
                  <div className="h-3 rounded-lg w-4/5" style={{ background: "rgba(255,255,255,0.10)" }} />
                  <div className="grid grid-cols-3 gap-2 mt-4">
                    {[...Array(6)].map((_, i) => (
                      <div
                        key={i}
                        className="h-16 rounded-xl"
                        style={{ background: i % 2 === 0 ? "rgba(116,72,245,0.4)" : "rgba(65,199,215,0.3)" }}
                      />
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <div className="h-8 rounded-lg flex-1" style={{ background: "rgba(116,72,245,0.7)" }} />
                    <div className="h-8 rounded-lg flex-1" style={{ background: "rgba(65,199,215,0.4)" }} />
                  </div>
                </div>
              </div>

              {/* Floating card */}
              <motion.div
                className="absolute -bottom-5 -right-6 rounded-2xl px-4 py-3 flex items-center gap-3"
                style={{
                  background: "rgba(255,255,255,0.95)",
                  boxShadow: "0 8px 32px rgba(0,0,0,0.15)",
                }}
                animate={{ y: [0, -6, 0] }}
                transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-extrabold"
                  style={{ background: "linear-gradient(135deg,#7448f5,#5a32c8)" }}
                >
                  ✦
                </div>
                <div>
                  <div className="text-xs font-extrabold" style={{ color: "#1f1f2e" }}>مشروع ناجح</div>
                  <div className="text-xs" style={{ color: "#6b6b7a" }}>+376 مشروع مكتمل</div>
                </div>
              </motion.div>

              {/* Top floating badge */}
              <motion.div
                className="absolute -top-4 -left-6 rounded-xl px-3 py-2"
                style={{
                  background: "#41c7d7",
                  boxShadow: "0 4px 20px rgba(65,199,215,0.4)",
                  color: "#fff",
                  fontSize: 13,
                  fontWeight: 800,
                }}
                animate={{ y: [0, 5, 0] }}
                transition={{ repeat: Infinity, duration: 2.5, ease: "easeInOut", delay: 0.5 }}
              >
                ⭐ 4.7 تقييم
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Wave bottom */}
      <div className="absolute bottom-0 left-0 right-0 pointer-events-none">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0,30 C360,60 1080,0 1440,30 L1440,60 L0,60 Z" fill="#f7f8fc" />
        </svg>
      </div>
    </section>
  );
}
