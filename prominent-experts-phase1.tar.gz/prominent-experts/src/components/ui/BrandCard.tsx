"use client";
import { motion } from "framer-motion";

interface BrandCardProps {
  children: React.ReactNode;
  className?: string;
  purple?: boolean;
}

export default function BrandCard({
  children,
  className = "",
  purple = false,
}: BrandCardProps) {
  return (
    <motion.div
      className={`rounded-2xl p-6 transition-all duration-300 ${className}`}
      style={
        purple
          ? {
              background: "linear-gradient(135deg, #7448f5 0%, #5a32c8 100%)",
              color: "#fff",
            }
          : {
              background: "#fff",
              boxShadow: "0 4px 24px rgba(116,72,245,0.08)",
            }
      }
      whileHover={{
        y: -4,
        boxShadow: purple
          ? "0 12px 40px rgba(116,72,245,0.35)"
          : "0 8px 40px rgba(116,72,245,0.16)",
      }}
    >
      {children}
    </motion.div>
  );
}
