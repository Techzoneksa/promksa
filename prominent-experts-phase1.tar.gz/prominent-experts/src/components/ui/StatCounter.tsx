"use client";
import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
import { Star, Users, Briefcase, Award } from "lucide-react";

const ICONS = { Star, Users, Briefcase, Award };

interface StatCounterProps {
  value: number;
  suffix: string;
  label: string;
  icon: keyof typeof ICONS;
  delay?: number;
}

export default function StatCounter({
  value,
  suffix,
  label,
  icon,
  delay = 0,
}: StatCounterProps) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true });
  const Icon = ICONS[icon];

  useEffect(() => {
    if (!inView) return;
    const timer = setTimeout(() => {
      const duration = 1500;
      const steps = 60;
      const increment = value / steps;
      let current = 0;
      const interval = setInterval(() => {
        current += increment;
        if (current >= value) {
          setCount(value);
          clearInterval(interval);
        } else {
          setCount(
            value % 1 !== 0 ? parseFloat(current.toFixed(1)) : Math.floor(current)
          );
        }
      }, duration / steps);
      return () => clearInterval(interval);
    }, delay * 1000);
    return () => clearTimeout(timer);
  }, [inView, value, delay]);

  return (
    <div
      ref={ref}
      className="bg-white rounded-2xl p-6 text-center flex flex-col items-center gap-3"
      style={{ boxShadow: "0 4px 24px rgba(116,72,245,0.10)" }}
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center"
        style={{ background: "#f4f0ff" }}
      >
        <Icon size={22} style={{ color: "#7448f5" }} />
      </div>
      <div className="text-3xl font-extrabold" style={{ color: "#1f1f2e" }}>
        {count}
        {suffix}
      </div>
      <div className="text-sm font-medium" style={{ color: "#6b6b7a" }}>
        {label}
      </div>
    </div>
  );
}
