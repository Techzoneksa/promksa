"use client";
import Reveal from "./Reveal";

interface SectionTitleProps {
  badge?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
  light?: boolean;
}

export default function SectionTitle({
  badge,
  title,
  subtitle,
  center = true,
  light = false,
}: SectionTitleProps) {
  return (
    <div className={`mb-12 ${center ? "text-center" : ""}`}>
      {badge && (
        <Reveal>
          <span
            className="inline-block text-sm font-bold mb-3 px-4 py-1 rounded-full"
            style={{
              background: light ? "rgba(255,255,255,0.15)" : "#f4f0ff",
              color: light ? "#fff" : "#7448f5",
            }}
          >
            {badge}
          </span>
        </Reveal>
      )}
      <Reveal delay={0.05}>
        <h2
          className="text-3xl md:text-4xl font-extrabold leading-tight mb-4"
          style={{ color: light ? "#fff" : "#1f1f2e" }}
        >
          {title}
        </h2>
      </Reveal>
      {subtitle && (
        <Reveal delay={0.1}>
          <p
            className="text-base md:text-lg max-w-2xl mx-auto leading-relaxed"
            style={{ color: light ? "rgba(255,255,255,0.75)" : "#6b6b7a" }}
          >
            {subtitle}
          </p>
        </Reveal>
      )}
    </div>
  );
}
