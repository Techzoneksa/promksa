"use client";
import { motion } from "framer-motion";
import Link from "next/link";

interface CTAButtonProps {
  href: string;
  children: React.ReactNode;
  variant?: "primary" | "outline" | "cyan" | "white-outline";
  external?: boolean;
  className?: string;
}

export default function CTAButton({
  href,
  children,
  variant = "primary",
  external = false,
  className = "",
}: CTAButtonProps) {
  const base =
    "inline-flex items-center justify-center gap-2 font-bold text-sm px-6 py-3 rounded-[10px] transition-all duration-200 cursor-pointer";

  const styles: Record<string, string> = {
    primary:
      "bg-[#7448f5] text-white hover:bg-[#5a32c8] shadow-md hover:shadow-lg",
    outline:
      "border-2 border-[#7448f5] text-[#7448f5] bg-transparent hover:bg-[#7448f5] hover:text-white",
    cyan: "bg-[#41c7d7] text-white hover:bg-[#2db5c5]",
    "white-outline":
      "border-2 border-white text-white bg-transparent hover:bg-white hover:text-[#7448f5]",
  };

  const cls = `${base} ${styles[variant]} ${className}`;

  if (external) {
    return (
      <motion.a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={cls}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
      >
        {children}
      </motion.a>
    );
  }

  return (
    <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
      <Link href={href} className={cls}>
        {children}
      </Link>
    </motion.div>
  );
}
