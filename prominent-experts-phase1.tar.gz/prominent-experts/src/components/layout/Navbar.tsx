"use client";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { NAV_LINKS, WHATSAPP_URL } from "@/lib/constants";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className="fixed top-0 right-0 left-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(255,255,255,0.97)" : "rgba(255,255,255,0.0)",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        boxShadow: scrolled ? "0 2px 20px rgba(116,72,245,0.08)" : "none",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo right (RTL) */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-extrabold text-lg"
              style={{ background: "linear-gradient(135deg,#7448f5,#5a32c8)" }}
            >
              P
            </div>
            <span
              className="font-extrabold text-lg hidden sm:block"
              style={{ color: scrolled ? "#1f1f2e" : "#fff", textShadow: scrolled ? "none" : "0 1px 8px rgba(0,0,0,0.3)" }}
            >
              بروميننت اكسبيرتس
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-6">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-sm font-bold transition-colors duration-200 hover:text-[#7448f5]"
                style={{ color: scrolled ? "#1f1f2e" : "rgba(255,255,255,0.9)" }}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-bold px-5 py-2.5 rounded-[10px] transition-all duration-200 hover:scale-105"
              style={{
                background: "linear-gradient(135deg,#7448f5,#5a32c8)",
                color: "#fff",
                boxShadow: "0 4px 14px rgba(116,72,245,0.3)",
              }}
            >
              تواصل معنا
            </a>
          </div>

          {/* Mobile hamburger */}
          <button
            className="lg:hidden p-2 rounded-lg"
            style={{ color: scrolled ? "#1f1f2e" : "#fff" }}
            onClick={() => setOpen(!open)}
            aria-label="القائمة"
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="lg:hidden border-t"
            style={{ background: "#fff", borderColor: "#f4f0ff" }}
          >
            <div className="px-4 py-4 flex flex-col gap-3">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="text-sm font-bold py-2 px-3 rounded-lg hover:bg-[#f4f0ff] transition-colors"
                  style={{ color: "#1f1f2e" }}
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-bold py-3 px-4 rounded-[10px] text-center mt-2"
                style={{
                  background: "linear-gradient(135deg,#7448f5,#5a32c8)",
                  color: "#fff",
                }}
                onClick={() => setOpen(false)}
              >
                تواصل معنا
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
