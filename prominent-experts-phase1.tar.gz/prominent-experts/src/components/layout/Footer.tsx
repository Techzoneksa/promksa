"use client";
import Link from "next/link";
import { FOOTER_SERVICES, FOOTER_SUPPORT, WHATSAPP_URL } from "@/lib/constants";

export default function Footer() {
  return (
    <footer>
      {/* Main footer — deep purple */}
      <div style={{ background: "#2b145f" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand col */}
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white font-extrabold text-lg"
                  style={{ background: "linear-gradient(135deg,#7448f5,#41c7d7)" }}
                >
                  P
                </div>
                <span className="font-extrabold text-white text-lg">
                  بروميننت اكسبيرتس
                </span>
              </div>
              <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>
                مؤسسة سعودية رائدة متخصصة في تصميم المواقع وبرمجة التطبيقات والهوية البصرية والتسويق الرقمي.
              </p>
              <div className="flex items-center gap-3 mt-5">
                {[
                  { label: "f", href: "https://facebook.com/promksaa", title: "Facebook" },
                  { label: "in", href: "https://instagram.com/promksa", title: "Instagram" },
                  { label: "𝕏", href: "https://x.com/promksa", title: "Twitter/X" },
                  { label: "li", href: "https://linkedin.com/in/prominent-experts", title: "LinkedIn" },
                ].map(({ label, href, title }) => (
                  <a
                    key={title}
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={title}
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-extrabold transition-all hover:scale-110"
                    style={{ background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.8)" }}
                  >
                    {label}
                  </a>
                ))}
              </div>
            </div>

            {/* Services */}
            <div>
              <h4 className="font-extrabold text-white mb-4 text-base">الخدمات</h4>
              <ul className="space-y-2.5">
                {FOOTER_SERVICES.map((item) => (
                  <li key={item.label}>
                    <Link
                      href={item.href}
                      className="text-sm transition-colors hover:text-[#41c7d7]"
                      style={{ color: "rgba(255,255,255,0.65)" }}
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="font-extrabold text-white mb-4 text-base">الدعم والمساعدة</h4>
              <ul className="space-y-2.5">
                {FOOTER_SUPPORT.map((item) => (
                  <li key={item.label}>
                    <Link
                      href={item.href}
                      className="text-sm transition-colors hover:text-[#41c7d7]"
                      style={{ color: "rgba(255,255,255,0.65)" }}
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-extrabold text-white mb-4 text-base">تواصل معنا</h4>
              <div className="space-y-3">
                <p className="text-sm" style={{ color: "rgba(255,255,255,0.65)" }}>
                  📍 المملكة العربية السعودية — جدة
                </p>
                <p className="text-sm" style={{ color: "rgba(255,255,255,0.65)" }}>
                  📞 966595394940+
                </p>
                <a
                  href={WHATSAPP_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-bold px-4 py-2 rounded-lg mt-2 transition-all hover:scale-105"
                  style={{ background: "#25d366", color: "#fff" }}
                >
                  واتساب مباشر
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom cyan bar */}
      <div
        className="py-3 px-4 text-center text-sm font-bold"
        style={{ background: "#41c7d7", color: "#fff" }}
      >
        جميع الحقوق محفوظة © 2026 Prominent Experts — بروميننت اكسبيرتس لحلول الأعمال
      </div>
    </footer>
  );
}
