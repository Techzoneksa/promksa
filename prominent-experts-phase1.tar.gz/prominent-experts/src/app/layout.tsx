import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: "وكالة تصميم وتسويق رقمي في السعودية | بروميننت اكسبيرتس",
  description:
    "وكالة رقمية متكاملة في السعودية نقدم تصميم مواقع ومتاجر، تطوير تطبيقات، وتسويق رقمي يساعدك على زيادة مبيعاتك والانطلاق بقوة.",
};

// Load Almarai font via CSS @import in globals.css

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <head />
      <body>
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
