import HeroSection from "@/components/sections/HeroSection";
import StatsSection from "@/components/sections/StatsSection";
import TechPlatformsStrip from "@/components/sections/TechPlatformsStrip";
import AboutTeaser from "@/components/sections/AboutTeaser";
import ServicesSection from "@/components/sections/ServicesSection";
import ClientsSection from "@/components/sections/ClientsSection";
import PortfolioSection from "@/components/sections/PortfolioSection";
import WhyUsSection from "@/components/sections/WhyUsSection";
import TestimonialsSection from "@/components/sections/TestimonialsSection";
import ContactSection from "@/components/sections/ContactSection";
import TechStackSection from "@/components/sections/TechStackSection";
import FinalCTASection from "@/components/sections/FinalCTASection";

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <StatsSection />
      <TechPlatformsStrip />
      <AboutTeaser />
      <ServicesSection />
      <ClientsSection />
      <PortfolioSection />
      <WhyUsSection />
      <TestimonialsSection />
      <ContactSection />
      <TechStackSection />
      <FinalCTASection />
    </>
  );
}
