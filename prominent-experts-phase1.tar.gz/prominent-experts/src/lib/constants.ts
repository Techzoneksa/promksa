// ===== BRAND COLORS =====
export const COLORS = {
  purplePrimary: "#7448f5",
  purpleDeep: "#2b145f",
  purpleMid: "#5a32c8",
  purpleLight: "#f4f0ff",
  purpleFooter: "#2b145f",
  cyan: "#41c7d7",
  cyanLight: "#e0f7fa",
  bgLight: "#f7f8fc",
  textDark: "#1f1f2e",
  textMuted: "#6b6b7a",
  white: "#ffffff",
} as const;

// ===== NAV LINKS =====
export const NAV_LINKS = [
  { label: "الرئيسية", href: "/" },
  { label: "تصميم المواقع", href: "#services" },
  { label: "تصميم المتاجر", href: "#services" },
  { label: "تصميم التطبيقات", href: "#services" },
  { label: "الهوية البصرية", href: "#services" },
] as const;

// ===== STATS =====
export const STATS = [
  { value: 4.7, suffix: "", label: "تقييم العملاء", icon: "Star" },
  { value: 129, suffix: "+", label: "عميل راضٍ", icon: "Users" },
  { value: 376, suffix: "+", label: "مشروع ناجح", icon: "Briefcase" },
  { value: 15, suffix: "+", label: "سنة خبرة", icon: "Award" },
] as const;

// ===== SERVICES =====
export const SERVICES = [
  {
    id: 1,
    icon: "Monitor",
    title: "تصميم المواقع",
    description: "مواقع إلكترونية احترافية متوافقة مع SEO وسريعة الأداء",
    link: "#",
  },
  {
    id: 2,
    icon: "ShoppingCart",
    title: "تصميم المتاجر",
    description: "متاجر إلكترونية متكاملة على سلة وزد وووردبريس وشوبيفاي",
    link: "#",
  },
  {
    id: 3,
    icon: "Smartphone",
    title: "برمجة التطبيقات",
    description: "تطبيقات جوال iOS وAndroid بتجربة مستخدم استثنائية",
    link: "#",
  },
  {
    id: 4,
    icon: "Palette",
    title: "تصميم الهوية البصرية",
    description: "هوية بصرية متكاملة تعكس قيم علامتك التجارية",
    link: "#",
  },
  {
    id: 5,
    icon: "TrendingUp",
    title: "التسويق الرقمي",
    description: "حملات تسويقية مدروسة تستهدف جمهورك وتضاعف مبيعاتك",
    link: "#",
  },
  {
    id: 6,
    icon: "Link",
    title: "الربط والتكامل",
    description: "ربط الأنظمة والمنصات لضمان انسيابية العمل ورفع الكفاءة",
    link: "#",
  },
] as const;

// ===== TECH PLATFORMS =====
export const TECH_PLATFORMS = [
  "Salla", "Zid", "Shopify", "WordPress", "OpenCart", "WooCommerce", "Magento",
] as const;

// ===== TECH STACK =====
export const TECH_STACK = [
  { name: "PHP", icon: "💻" },
  { name: "Laravel", icon: "🔧" },
  { name: "Python", icon: "🐍" },
  { name: "JavaScript", icon: "⚡" },
  { name: "React", icon: "⚛️" },
  { name: "Next.js", icon: "🚀" },
  { name: "WordPress", icon: "📝" },
  { name: "Shopify", icon: "🛒" },
  { name: "Salla", icon: "🏪" },
  { name: "Zid", icon: "🔗" },
  { name: "Flutter", icon: "📱" },
  { name: "Firebase", icon: "🔥" },
] as const;

// ===== CLIENTS (placeholder names) =====
export const CLIENTS = Array.from({ length: 24 }, (_, i) => `client-${i + 1}`);

// ===== PROJECTS =====
export const PROJECTS = [
  {
    id: 1,
    title: "شركة أحافير المحدودة",
    category: "مواقع",
    tag: "مقاولات وإنشاءات",
    color: "#7448f5",
  },
  {
    id: 2,
    title: "شركة سهم العقارية",
    category: "مواقع",
    tag: "تطوير عقارات",
    color: "#5a32c8",
  },
  {
    id: 3,
    title: "مواسم للسفر والسياحة",
    category: "مواقع",
    tag: "سفر وسياحة",
    color: "#41c7d7",
  },
  {
    id: 4,
    title: "Next Care",
    category: "مواقع",
    tag: "الرعاية الطبية",
    color: "#7448f5",
  },
  {
    id: 5,
    title: "كيدز زون",
    category: "مواقع",
    tag: "رياض أطفال",
    color: "#5a32c8",
  },
  {
    id: 6,
    title: "اكسترا باسيكال",
    category: "متاجر",
    tag: "بيع وتأجير الدراجات",
    color: "#41c7d7",
  },
] as const;

// ===== TESTIMONIALS =====
export const TESTIMONIALS = [
  {
    id: 1,
    name: "حامد الشيخي",
    company: "شركة التوباز للتطوير العقاري",
    text: "أحمد شخص متعاون جدًا ومرن، والنتيجة كانت أكثر مما توقعت. فريق محترف يفهم احتياجات العميل ويحرص على الجودة.",
    rating: 5,
  },
  {
    id: 2,
    name: "هبة الكثيري",
    company: "شركة أبعاد",
    text: "أنجزوا الشغل بدقة وسرعة، وكان التواصل سهلاً وواضحاً طوال المشروع. أنصح بالتعامل معهم بكل ثقة.",
    rating: 5,
  },
  {
    id: 3,
    name: "عبدالله الشريف",
    company: "شركة مهل للمياه",
    text: "شغل مرتب وأسلوب محترم، الفريق يحرص على إرضاء العميل في كل تفصيلة. سنتعاون معهم في مشاريع قادمة.",
    rating: 5,
  },
] as const;

// ===== WHY US POINTS =====
export const WHY_US = [
  "خبرة عميقة في السوق السعودي والعالمي",
  "تصميمات مخصصة وليست قوالب جاهزة",
  "حلول تقنية وتسويقية متكاملة تحت سقف واحد",
  "فريق يجمع التصميم والتسويق والتقنية",
  "متابعة وتحسين مستمر بعد الإطلاق",
] as const;

// ===== FOOTER =====
export const FOOTER_SERVICES = [
  { label: "تصميم المواقع", href: "#" },
  { label: "تصميم المتاجر", href: "#" },
  { label: "برمجة التطبيقات", href: "#" },
  { label: "تصميم الهوية البصرية", href: "#" },
  { label: "التسويق الرقمي", href: "#" },
];

export const FOOTER_SUPPORT = [
  { label: "الدعم الفني", href: "#" },
  { label: "الشكاوى والاقتراحات", href: "#" },
  { label: "الأسئلة الشائعة", href: "#" },
  { label: "سياسة الخصوصية", href: "#" },
  { label: "طرق الدفع", href: "#" },
];

export const WHATSAPP_URL = "https://wa.me/966595394940";
